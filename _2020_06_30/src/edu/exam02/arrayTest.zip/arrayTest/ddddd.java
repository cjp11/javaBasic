package edu.exam02.arrayTest;

public class ddddd {

	public static void main(String[] args) {
		System.out.println("AB\nC" + "D\n\nEFG");

	}

}
